CREATE OR REPLACE VIEW inventory_risk_view AS
SELECT 
    inv.item_id,
    inv.item_name,
    inv.current_qty,
    inv.avg_daily_demand,
    inv.days_on_hand,
    f.status AS fda_shortage_status,
    f.date_updated AS fda_status_updated_on,
    f.manufacturer,
    f.reason AS shortage_reason
FROM inventory_days_on_hand_view inv
LEFT JOIN fda_shortages f
    ON LOWER(inv.item_name) = LOWER(f.drug_name);