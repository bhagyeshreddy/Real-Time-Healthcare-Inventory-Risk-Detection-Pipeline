import boto3
import json
import os
import time

redshift = boto3.client('redshift-data')
sns = boto3.client('sns')

WORKGROUP_NAME = os.environ['REDSHIFT_WORKGROUP']
DATABASE = os.environ['REDSHIFT_DATABASE']
SECRET_ARN = os.environ['REDSHIFT_SECRET_ARN']
SNS_TOPIC_ARN = os.environ['SNS_TOPIC_ARN']

def lambda_handler(event, context):
    query = """
        SELECT item_name, days_on_hand, fda_shortage_status
        FROM inventory_risk_view
        WHERE days_on_hand < 7 OR fda_shortage_status = 'Ongoing';
    """

    try:
        response = redshift.execute_statement(
            WorkgroupName=WORKGROUP_NAME,
            Database=DATABASE,
            SecretArn=SECRET_ARN,
            Sql=query
        )

        statement_id = response["Id"]
        status = "STARTED"
        while status in ["STARTED", "SUBMITTED", "PICKED", "RUNNING"]:
            status_response = redshift.describe_statement(Id=statement_id)
            status = status_response["Status"]
            if status in ["FAILED", "ABORTED"]:
                raise Exception(f"Redshift query failed: {status_response}")
            time.sleep(1)

        result = redshift.get_statement_result(Id=statement_id)
        records = result.get("Records", [])

        def get_value(cell):
            return next(iter(cell.values()))

        if records:
            formatted = "\n".join(
                f"- {get_value(r[0])}: {get_value(r[1])} days left ({get_value(r[2])})"
                for r in records
            )

            message = f"🚨 Inventory Alert 🚨\nThe following drugs need attention:\n\n{formatted}"

            sns.publish(
                TopicArn=SNS_TOPIC_ARN,
                Subject="🚨 Redshift Inventory Risk Alert",
                Message=message
            )

            return {
                "statusCode": 200,
                "message": "Alert sent.",
                "details": formatted
            }
        else:
            return {
                "statusCode": 200,
                "message": "No risks found today 🚦"
            }

    except Exception as e:
        return {
            "statusCode": 500,
            "error": str(e)
        }