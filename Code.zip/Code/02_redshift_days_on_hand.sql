SELECT 
    i.item_id,
    i.item_name,
    i.current_qty,
    AVG(d.total_units_dispensed) AS avg_daily_demand,
    CASE 
        WHEN AVG(d.total_units_dispensed) IS NULL OR AVG(d.total_units_dispensed) = 0 THEN 999
        ELSE ROUND(i.current_qty / AVG(d.total_units_dispensed), 2)
    END AS days_on_hand
FROM inventory i
LEFT JOIN daily_demand d ON i.item_id = d.drug_id
GROUP BY i.item_id, i.item_name, i.current_qty;